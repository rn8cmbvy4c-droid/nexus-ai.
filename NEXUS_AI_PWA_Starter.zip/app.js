const $=s=>document.querySelector(s);
const load=(k,f)=>{try{return JSON.parse(localStorage.getItem(k))??f}catch{return f}};
const save=(k,v)=>localStorage.setItem(k,JSON.stringify(v));
let tasks=load('nexus_tasks',[]);
let transactions=load('nexus_transactions',[]);
let financeType='expense';
const pages=['homePage','aiPage','tasksPage','financePage','profilePage'];
function go(id){pages.forEach(p=>$('#'+p).classList.toggle('active',p===id));document.querySelectorAll('.tab').forEach(t=>t.classList.toggle('active',t.dataset.page===id));}
document.querySelectorAll('[data-page]').forEach(b=>b.addEventListener('click',()=>go(b.dataset.page)));
document.querySelectorAll('[data-go]').forEach(b=>b.addEventListener('click',()=>go(b.dataset.go)));
$('#profileShortcut').addEventListener('click',()=>go('profilePage'));
function renderTasks(){const pending=tasks.filter(t=>!t.done);$('#homeTasks').innerHTML=pending.length?pending.slice(0,3).map(t=>taskHTML(t)).join(''):'<div class="empty">Пока нет активных задач</div>';$('#allTasks').innerHTML=tasks.length?tasks.map(t=>taskHTML(t)).join(''):'<div class="empty">Задач пока нет. Добавь первую выше.</div>';document.querySelectorAll('[data-task]').forEach(el=>el.addEventListener('change',()=>{const t=tasks.find(x=>x.id===el.dataset.task);if(t){t.done=el.checked;save('nexus_tasks',tasks);renderTasks()}}));}
function taskHTML(t){return `<label class="task-item ${t.done?'done':''}"><input type="checkbox" data-task="${t.id}" ${t.done?'checked':''}><span class="task-name">${escapeHTML(t.title)}</span></label>`}
function escapeHTML(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function addTask(title){title=title.trim();if(!title)return;tasks.unshift({id:crypto.randomUUID?.()||String(Date.now()),title,done:false});save('nexus_tasks',tasks);renderTasks()}
$('#taskForm').addEventListener('submit',e=>{e.preventDefault();addTask($('#taskInput').value);$('#taskInput').value=''});
$('#clearDone').addEventListener('click',()=>{tasks=tasks.filter(t=>!t.done);save('nexus_tasks',tasks);renderTasks()});
function chat(text,who){const d=document.createElement('div');d.className='bubble '+who;d.textContent=text;$('#chatMessages').append(d);$('#chatMessages').scrollTop=$('#chatMessages').scrollHeight}
$('#chatForm').addEventListener('submit',e=>{e.preventDefault();const v=$('#chatInput').value.trim();if(!v)return;chat(v,'user');$('#chatInput').value='';const m=v.match(/(?:добавь|создай|запиши)\s+(?:задачу\s+)?(.+)/i);if(m){addTask(m[1]);chat('Добавил задачу в локальный список. Открой раздел «Задачи», чтобы проверить. Пока я выполняю только простые локальные команды; полноценный ИИ подключим отдельным этапом.','assistant')}else{chat('Я получил поручение. Сейчас работаю в демонстрационном режиме и не подключён к настоящей ИИ-модели. На следующем этапе добавим интеллектуальное ядро.','assistant')}});
function renderFinance(){const sum=transactions.reduce((a,t)=>a+(t.type==='income'?t.amount:-t.amount),0);$('#balance').textContent=new Intl.NumberFormat('ru-RU').format(sum)+' ₽';$('#transactions').innerHTML=transactions.length?transactions.map(t=>`<div class="transaction"><span>${escapeHTML(t.title)}</span><b class="amount ${t.type==='income'?'plus':'minus'}">${t.type==='income'?'+':'−'}${new Intl.NumberFormat('ru-RU').format(t.amount)} ₽</b></div>`).join(''):'<div class="empty">Операций пока нет</div>'}
$('#expenseBtn').addEventListener('click',()=>setFinanceType('expense'));$('#incomeBtn').addEventListener('click',()=>setFinanceType('income'));
function setFinanceType(t){financeType=t;$('#expenseBtn').classList.toggle('selected',t==='expense');$('#incomeBtn').classList.toggle('selected',t==='income')}
$('#financeForm').addEventListener('submit',e=>{e.preventDefault();const title=$('#financeTitle').value.trim(),amount=Number($('#financeAmount').value);if(!title||!Number.isFinite(amount)||amount<=0)return;transactions.unshift({title,amount,type:financeType});save('nexus_transactions',transactions);$('#financeTitle').value='';$('#financeAmount').value='';renderFinance()});
$('#resetApp').addEventListener('click',()=>{if(confirm('Удалить все локальные задачи и финансовые записи?')){localStorage.removeItem('nexus_tasks');localStorage.removeItem('nexus_transactions');tasks=[];transactions=[];renderTasks();renderFinance()}});
if('serviceWorker' in navigator && location.protocol.startsWith('http'))navigator.serviceWorker.register('./sw.js').catch(()=>{});
renderTasks();renderFinance();